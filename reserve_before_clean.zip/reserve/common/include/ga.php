
<!-- GoogleAnalytics -->
<!-- Global site tag (gtag.js) - Google Analytics  (old) -->
<?php /*?><script async src="https://www.googletagmanager.com/gtag/js?id=UA-147696886-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-147696886-1');
</script><?php */?>
<!-- //GoogleAnalytics -->

<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-166622808-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-166622808-1');
</script>